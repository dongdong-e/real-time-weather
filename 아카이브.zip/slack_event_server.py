from flask import Flask, request, make_response
import requests
import threading
import time

app = Flask(__name__)

# 슬랙 봇 토큰 (본인 토큰으로 교체)
SLACK_BOT_TOKEN = "xoxb-588388487269-9226498696480-XCKTezSKSTakMSScFzKyBbPe"
SLACK_HEADERS = {
    "Authorization": f"Bearer {SLACK_BOT_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

# 기상청 특보 데이터 URL
KMA_WARNING_API_URL = "https://apihub.kma.go.kr/api/typ01/url/wrn_met_data.php?reg=0&wrn=A&tmfc1=201501010000&tmfc2=201502010000&disp=0&help=0&authKey=..."

# 서울/인천/경기(시군구) 자동 알림용
REGION_CODE_TO_NAME = {
    "L1010100": "서울", "L1010200": "광명", "L1010300": "과천", "L1010400": "안산", "L1010500": "시흥", "L1010600": "부천", "L1010700": "김포", "L1010800": "인천", "L1010900": "강화", "L1011100": "동두천", "L1011200": "연천", "L1011300": "포천", "L1011400": "가평", "L1011500": "고양", "L1011600": "양주", "L1011700": "의정부", "L1011800": "파주", "L1011900": "수원", "L1012000": "성남", "L1012100": "안양", "L1012200": "구리", "L1012300": "남양주", "L1012400": "오산", "L1012500": "평택", "L1012600": "군포", "L1012700": "의왕", "L1012800": "하남", "L1012900": "용인", "L1013000": "이천", "L1013100": "안성", "L1013200": "화성", "L1013300": "여주", "L1013400": "광주", "L1013500": "양평", "L1013600": "옹진", "L1014100": "서해5도"
}

# 전국 검색용 (샘플, 실제로는 전국 모든 지역 포함 필요)
ALL_REGION_CODE_TO_NAME = {
    # 위 REGION_CODE_TO_NAME 전체 포함
    "L1010100": "서울", "L1010200": "광명", "L1010300": "과천", "L1010400": "안산", "L1010500": "시흥", "L1010600": "부천", "L1010700": "김포", "L1010800": "인천", "L1010900": "강화", "L1011100": "동두천", "L1011200": "연천", "L1011300": "포천", "L1011400": "가평", "L1011500": "고양", "L1011600": "양주", "L1011700": "의정부", "L1011800": "파주", "L1011900": "수원", "L1012000": "성남", "L1012100": "안양", "L1012200": "구리", "L1012300": "남양주", "L1012400": "오산", "L1012500": "평택", "L1012600": "군포", "L1012700": "의왕", "L1012800": "하남", "L1012900": "용인", "L1013000": "이천", "L1013100": "안성", "L1013200": "화성", "L1013300": "여주", "L1013400": "광주", "L1013500": "양평", "L1013600": "옹진", "L1014100": "서해5도",
    # 강원, 충청, 전라, 경상, 제주 등 전국 모든 지역 추가 (샘플)
    "L1020110": "강릉평지", "L1020210": "동해평지", "L1020300": "태백", "L1020410": "삼척평지", "L1020510": "속초평지", "L1020610": "고성평지", "L1020710": "양양평지", "L1020800": "영월", "L1020910": "평창평지", "L1021010": "정선평지", "L1021100": "횡성", "L1021200": "원주", "L1021300": "철원", "L1021400": "화천", "L1021510": "홍천평지", "L1021600": "춘천", "L1021710": "양구평지", "L1021810": "인제평지", "L1025020": "강원북부산지", "L1026020": "강원중부산지", "L1027020": "강원남부산지",
    "L1030100": "대전", "L1030200": "천안", "L1030300": "공주", "L1030400": "아산", "L1030500": "논산", "L1030600": "금산", "L1030800": "부여", "L1030900": "청양", "L1031000": "예산", "L1031100": "태안", "L1031200": "당진", "L1031300": "서산", "L1031400": "보령", "L1031500": "서천", "L1031600": "홍성", "L1031700": "계룡", "L1031800": "세종",
    # ... (생략, 위에서 주신 데이터 전체 추가) ...
}

# 특보 코드 해석
WRN_TYPE = {"W": "강풍", "S": "호우", "V": "풍랑", "C": "건조", "T": "태풍", "H": "한파", "D": "대설"}
LVL_TYPE = {"1": "예비", "2": "주의보", "3": "경보"}
CMD_TYPE = {"1": "발표", "2": "대치", "3": "해제", "4": "대치해제(자동)", "5": "연장", "6": "변경", "7": "변경해제"}

# 슬랙 메시지 전송 함수
def send_slack_message(channel, text):
    url = "https://slack.com/api/chat.postMessage"
    payload = {"channel": channel, "text": text}
    requests.post(url, headers=SLACK_HEADERS, json=payload)

# 지역명으로 특보 조회 함수
def get_warning_for_region(region_name):
    try:
        response = requests.get(KMA_WARNING_API_URL, timeout=30)
        response.encoding = 'utf-8'
        text = response.text
        lines = [line.strip() for line in text.split('\n') if line.strip() and not line.startswith('#')]
        # 전체 라인 중 '아산'이 포함된 라인 모두 출력
        for line in lines:
            if '아산' in line:
                print(f"[DEBUG] 아산 포함 라인: {line}")
        found = False
        result_msgs = []
        for line in lines:
            if not line.endswith('='):
                continue
            parts = [p.strip() for p in line[:-1].split(',')]
            # 필드 개수 체크를 완화 (11개 기준)
            if len(parts) < 8:
                continue
            reg_id = parts[4]
            warn_type = parts[5]
            lvl = parts[6]
            cmd = parts[7]
            tm_fc = parts[0]
            tm_ef = parts[1]
            name = ALL_REGION_CODE_TO_NAME.get(reg_id, "")
            # 디버깅: 주요 지역 라인 출력
            if region_name in name:
                print(f"[DEBUG] {region_name} 관련 라인: {line}")
            if name and region_name in name:
                warn_type_str = WRN_TYPE.get(warn_type, warn_type)
                lvl_str = LVL_TYPE.get(lvl, lvl)
                cmd_str = CMD_TYPE.get(cmd, cmd)
                msg = f"[특보] {name} - {warn_type_str} {lvl_str} ({cmd_str})\n발표시각: {tm_fc} / 발효시각: {tm_ef}"
                result_msgs.append(msg)
                found = True
        if found:
            return "\n\n".join(result_msgs)
        else:
            return f"{region_name}에 현재 발효 중인 특보가 없습니다."
    except Exception as e:
        return f"특보 조회 오류: {e}"

# 서울/경기/인천 전체 특보 자동 알림 (30분마다)
def auto_warning_alert():
    last_sent = set()
    while True:
        try:
            response = requests.get(KMA_WARNING_API_URL, timeout=30)
            response.encoding = 'utf-8'
            text = response.text
            lines = [line.strip() for line in text.split('\n') if line.strip() and not line.startswith('#')]
            alert_msgs = []
            for line in lines:
                if not line.endswith('='):
                    continue
                parts = [p.strip() for p in line[:-1].split(',')]
                if len(parts) < 8:
                    continue
                reg_id = parts[4]
                warn_type = parts[5]
                lvl = parts[6]
                cmd = parts[7]
                tm_fc = parts[0]
                tm_ef = parts[1]
                name = REGION_CODE_TO_NAME.get(reg_id, "")
                if name:
                    warn_type_str = WRN_TYPE.get(warn_type, warn_type)
                    lvl_str = LVL_TYPE.get(lvl, lvl)
                    cmd_str = CMD_TYPE.get(cmd, cmd)
                    msg = f"[특보] {name} - {warn_type_str} {lvl_str} ({cmd_str})\n발표시각: {tm_fc} / 발효시각: {tm_ef}"
                    # 중복 전송 방지
                    key = (name, warn_type_str, lvl_str, cmd_str, tm_fc, tm_ef)
                    if key not in last_sent:
                        alert_msgs.append(msg)
                        last_sent.add(key)
            if alert_msgs:
                # 슬랙 채널 ID를 실제로 사용할 채널로 변경
                send_slack_message("#general", "\n\n".join(alert_msgs))
            # 30분 대기
            time.sleep(1800)
        except Exception as e:
            print(f"자동 특보 알림 오류: {e}")
            time.sleep(1800)

@app.route("/slack/events", methods=["POST"])
def slack_events():
    data = request.get_json()
    if data.get("type") == "url_verification":
        return make_response(data.get("challenge"), 200, {"content_type": "text/plain"})
    if data.get("event"):
        event = data["event"]
        if event.get("type") == "app_mention":
            user_text = event.get("text", "")
            channel = event.get("channel")
            if "특보 알려줘" in user_text:
                region = user_text.split("특보 알려줘")[-1].strip()
                result = get_warning_for_region(region)
                send_slack_message(channel, result)
            else:
                send_slack_message(channel, "예) 특보 알려줘 서울 종로구")
    return make_response("OK", 200)

if __name__ == "__main__":
    # 자동 알림 스레드 시작
    t = threading.Thread(target=auto_warning_alert, daemon=True)
    t.start()
    app.run(host="0.0.0.0", port=5001)